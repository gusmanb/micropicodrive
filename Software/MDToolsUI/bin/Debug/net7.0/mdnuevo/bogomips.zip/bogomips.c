/*
 *                Standalone BogoMips program
 *
 * Based on code Linux kernel code in init/main.c and
 * include/linux/delay.h
 *
 * For more information on interpreting the results, see the BogoMIPS
 * Mini-HOWTO document.
 *
 * version: 1.3 
 *  author: Jeff Tranter (Jeff_Tranter@Mitel.COM)
 *
 * version: 1.4
 *  modif.: Thierry Godefroy
 *  - modified in order to work under QDOS/SMSQ as well (timing loop increased
 *    to 10 seconds instead of 1 second and buggy "clock()" function replaced
 *    with QDOS function "mt_rclck()").
 *  - "delay_s" added for 680x0 support (equivalent to the "CLASSIC_BOGOMIPS"
 *    option and faster than "PORTABLE_BOGOMIPS").
 * version: 1.5
 *  modif.: Thierry Godefroy
 *  - modified so to use the QDOS/SMS polling interrupt for timing (more
 *    accurate values).
 *  - timing loop now executed in supervisor mode so that multitasking cannot
 *    disturb the timing (no more need to kill all jobs before executing
 *    bogomips to get the maximum result).
 */

#include <stdio.h>
#include <time.h>

#ifdef CLASSIC_BOGOMIPS
/* the original code from the Linux kernel */
static __inline__ void delay(unsigned long loops)
{
  __asm__(".align 2,0x90\n1:\tdecl %0\n\tjns 1b": :"a" (loops):"ax");
}
#endif

#ifdef QNX_BOGOMIPS
/* version for QNX C compiler */
void delay(int loops);
#pragma aux delay = \
     "l1:"       \
     "dec eax"   \
     "jns l1"    \
     parm nomemory [eax] modify exact nomemory [eax];
#endif

#ifdef PORTABLE_BOGOMIPS
/* portable version */
static void delay(unsigned long loops)
{
  long i;
  for (i = loops; i >= 0 ; i--)
    ;
}
#endif

#ifdef QDOS
#include <qdos.h>
#include <string.h>

void delay(unsigned long);
void t_on(void);
void t_off(void);
void t_start(void);
void t_stop(void);
int  t_count(void);

unsigned long polling_frequency = 50;

#define CLOCK t_count()
#undef CLOCKS_PER_SEC
#define CLOCKS_PER_SEC polling_frequency

char _prog_name[]   = "BogoMips";
char _version[24]   = "v1.5";
char _copyright[32] = "QDOS/SMS forever !";

char *_endmsg = "\n\nPress a key to exit.";

struct WINDOWDEF _condetails  = { 208, 1, 0, 7, 350, 150, 80, 52};
void (*_consetup)() = consetup_title;

#define QDOS_ID  0xD2540000
#define ARGOS_ID 0xDC010000
#define SMS2_ID  0x53324154
#define SMSQ_ID  0x534D5351

void guess_polf(void)
{
  int t0;

  printf("Guessing polling frequency, please wait...\n");

  t_on();
  _super();
  t0 = mt_rclck() + 6;
  t_start();
  while(mt_rclck() < t0)
   ;
  t_stop();
  t0 = t_count();
  _user();
  t_off();
  if (t0 > 330)
    polling_frequency = 60;
  if (t0 > 393)
    polling_frequency = 71;
}

void pollfreq(void)
{
  short sys_polf, *temp2;
  unsigned long ver, os_type, *temp;
  int i;
  char version[5]="    ", os[10];

  struct REGS in;
  struct REGS out;

  in.D0 = 0.L;
  qdos1(&in, &out);
  temp = (unsigned long *) out.A0;
  os_type = *temp;
  temp2 = (short *) (out.A0 + 0x00A8);
  sys_polf = *temp2;
  ver = out.D2;

  for(i=3; i>=0; i--) {
    version[i] = (char) ver;
    ver >>= 8;
    }

  switch (os_type) {

    case QDOS_ID:
      strcpy(os, "QDOS");
      if (version[2] > 0x35)
        strcpy(os, "Minerva");
      guess_polf();
      break;

    case ARGOS_ID:
      strcpy(os, "ARGOS");
      polling_frequency = 50;
      break;

    case SMS2_ID:
      strcpy(os, "SMS2");
      polling_frequency = (unsigned long) sys_polf;
      break;

    case SMSQ_ID:
      strcpy(os, "SMSQ(/E)");
      polling_frequency = (unsigned long) sys_polf;
      break;

    default:
      strcpy(os, "unknown !");
      guess_polf();
      break;
  }

  printf("\nOS     : %s\nVersion: %s\n\n", os, version);
  printf("Assumed polling frequency is %d Hertz.\n", polling_frequency);
}

#else
#define CLOCK clock()
#endif

int main(void)
{
  unsigned long loops_per_sec = 1;
  unsigned long ticks;
  int err;

#ifdef QDOS
  pollfreq();
#endif

  printf("\nCalibrating delay loop...\n");
  fflush(stdout);

  while ((loops_per_sec <<= 1)) {

#ifdef QDOS
    t_on();
    t_start();
    _super();
#endif

    ticks = CLOCK;
    delay(loops_per_sec);
    ticks = CLOCK - ticks;

#ifdef QDOS
    _user();
    t_stop();
    t_off();
#endif

    if (ticks >= 10 * CLOCKS_PER_SEC) {
      loops_per_sec = (loops_per_sec / ticks) * CLOCKS_PER_SEC;
      printf("\nDone !  %lu.%02lu BogoMips\n",
             loops_per_sec/500000,
             (loops_per_sec/5000) % 100
             );
      return 0;
    }
  }

#ifdef QDOS
  t_stop();
  t_off();
#endif

  printf("failed\n");
  return -1;
}
